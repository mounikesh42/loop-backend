# Processing Confidence Score — v1.0 FINAL Bundle

Generated: 2026-06-02 07:57 UTC
Version: 1.0.0

## What this is

Closed bundle for processing_score v1.0 — the CBMI chain that evaluates Agisoft Metashape
processing report + deliverable files + processing manifest. Owns check-point residual
analysis as the moment-of-truth survey accuracy measurement.

## Architecture

- **Single scalar** processing_score per survey
- **Four blocks** (failure-axis): BA Quality 0.30 / Image Matching 0.30 / Control & Verification 0.25 / Deliverable Output 0.15
- **Evidence model**: Option A — processing report REQUIRED; processing_score = null when absent
- **Engine support v1**: Agisoft Metashape v1.7.x (ODM, Pix4D, RealityCapture deferred to v2+)
- **Parser**: keys off section headers (not page numbers) for Agisoft version resilience
- **Runtime independence**: reads its own evidence base (report, manifest, deliverables) plus
  pre_processing source artifacts/manifest for cross-source checks. Does NOT read upstream
  computed scores at runtime.

## Counts

- 4 source files
- 90 source fields
- 37 derived fields
- 38 indicators across 4 blocks
- 64 flags (1 global gate, 2 flag-only catastrophic/critical, scoring flags, advisory flags, handoffs)
- 39 catalogued problems (7 inherited + 32 native)
- All weights sum to 1.0 ✓

## Hard gate (zeroing)

- PROC_OUTPUT_CRS_MISMATCH — output CRS contradicts project requirement (CATASTROPHIC, zeros score via block)

## Flag-only signals (CATASTROPHIC/CRITICAL but score still computes)

- PROC_NO_MARKERS_AT_ALL — zero markers (CATASTROPHIC; bundle PPK-anchored only)
- PROC_NO_GCPS_USED — markers exist but all as CPs (CRITICAL; PPK-only)

## Verification status field

Separate categorical field, not score-gating:
- VERIFIED_RESIDUALS_PASS / MARGINAL / FAIL — CPs ≥5 with CP_RMSE thresholds
- UNVERIFIED_INSUFFICIENT_CPS — 1-4 CPs
- UNVERIFIED_NO_CPS — zero CPs

## Pressure-test result

Tested against three reference reports (same survey, different control configurations):

| Report | Configuration | Expected | Actual | Status |
|--------|--------------|----------|--------|--------|
| A | 3 CPs, 0 GCPs (PPK only) | worst | 84.3 | ✓ worst |
| B | 8 CPs, 0 GCPs (more verification) | middle | 84.6 | ✓ middle |
| C | 3 GCPs + 5 CPs (proper control) | best | 87.1 | ✓ best |

Rank ordering A < B < C confirms block weights at 0.30/0.30/0.25/0.15 are correct.

## Build history

- v0.1 DRAFT: 35 catalog rows (7 inherited + 27 native + 1 borderline-included)
- v0.2 DRAFT: User operational review pass — 8 OPERATIONAL tags, 2 severity downgrades (#3, #7),
  4 new rows (#36 internal transform, #37 localized reconstruction collapse, #38 DEM voids,
  #39 DSM-as-DTM), 3 chain-level concerns flagged
- v1.0 (this bundle):
  - Concern 1 (NULL when no report): Option A locked — different from pre-processing's Option B
    because processing has almost no non-report evidence
  - Concern 2 (block weights): 0.30/0.30/0.25/0.15 locked, validated by pressure-test
  - Concern 3 (parser fragility): section-header-keyed parsing locked
  - CV1 cp_rmse_score at 0.35 (moment-of-truth dominant intra-block)
  - IM7 localized_reconstruction at 0.10 with documented v1-partial / v2-full detection
  - BA4 optimization completeness threshold softened post-pressure-test: missing b1/b2 → 90 (was 70)
    — diagnosed as overcalibrated penalty for what is operationally a minor preference

## Known limitations (stated, not hidden)

See processing_confidence_score.json `processing_score.known_limitations` for full text.
Key items:
- Processing report REQUIRED — third-party-processed surveys without report addressed by future delivery layer
- Localized reconstruction collapse (#37) v1 PARTIAL detection via global proxies; full detection v2
- Per-camera position outliers (#8) v1 ENSEMBLE only; per-camera detail v2
- Software version known-buggy list (#33) v2 deliverable
- CP-GCP statistical independence (GCP#2) deferred v2
- High altitude variance (Drone FLG_011) deferred v2

## Next steps

1. processing_score v1.1 — add 5 per-deliverable views (ortho_score, dsm_score, dtm_score,
   point_cloud_score, mesh_3d_score) as configurations over v1.0 indicator layer.
   Same additive-extension pattern as pre_processing v1.1.
2. analytics_score chain
3. capture_score integration layer
4. Future delivery layer (per-customer-use-case deliverable fitness, addresses third-party-processed
   surveys without Agisoft report)

## Files in this bundle

- `processing_confidence_score.json` — Master JSON — all levels, fields, derivations, indicators, blocks, flags, problem coverage
- `processing_confidence_score.xlsx` — Excel workbook with 10 sheets (README + all CSVs)
- `processing_provenance_v1.html` — Full provenance documentation — flow diagram, all 6 levels, flags, problem coverage
- `01_source_files.csv` — Level 6 — source files
- `02_source_fields.csv` — Level 5 — source fields
- `03_derived_fields.csv` — Level 4 — derived fields
- `04_indicators.csv` — Level 3 — indicators with weights, thresholds, evidence requirements
- `05_building_blocks.csv` — Level 1 — 4 blocks with weights
- `06_processing_score.csv` — Level 0 — processing_score block composition
- `06b_processing_score_meta.csv` — Level 0 — processing_score metadata
- `07_flags.csv` — All 64 flags with severity, conditions, coverage
- `08_problem_coverage_map.csv` — All 39 problems mapped to indicators/flags
